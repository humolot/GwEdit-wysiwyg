<?php
use Jodit\Application;

class JoditRestApplication extends Application {
    
    function checkAuthentication() {
        
    }
}